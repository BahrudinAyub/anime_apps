class DataModel {
  final String gambarContinueWatching;

  DataModel({required this.gambarContinueWatching});
}

List<DataModel> dataListContinueWatching1 = [
  DataModel(gambarContinueWatching: 'assets/image/continue_1.png'),
  DataModel(gambarContinueWatching: 'assets/image/continue_2.png'),
];
