class DataModel {
  final String gambarCategoriesYouLike;

  DataModel({required this.gambarCategoriesYouLike});
}

List<DataModel> dataListCategoriesYouLike = [
  DataModel(gambarCategoriesYouLike: 'assets/image/categories_1.png'),
  DataModel(gambarCategoriesYouLike: 'assets/image/categories_2.png'),
  DataModel(gambarCategoriesYouLike: 'assets/image/categories_3.png'),
];
