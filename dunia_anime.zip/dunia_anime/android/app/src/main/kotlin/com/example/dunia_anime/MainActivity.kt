package com.example.dunia_anime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
